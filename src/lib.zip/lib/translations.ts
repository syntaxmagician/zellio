export type TranslationKey =
  | "nav.home"
  | "nav.about"
  | "nav.services"
  | "nav.whyUs"
  | "nav.portfolio"
  | "nav.contact"
  | "nav.startProject"
  | "nav.available"
  | "hero.badge"
  | "hero.titlePre"
  | "hero.titleAcc"
  | "hero.desc"
  | "hero.explore"
  | "hero.contact"
  | "service.whyChoose"
  | "service.timeline"
  | "service.tier"
  | "service.note"
  | "service.viewAll"
  | "service.elevate"
  | "service.custom-website-development"
  | "service.company-profile-website"
  | "service.landing-page-development"
  | "service.e-commerce-development"
  | "service.custom-web-application"
  | "service.admin-analytics-dashboards"
  | "service.mobile-app-development"
  | "service.erp-system-development"
  | "service.crm-system-development"
  | "service.hris-payroll-system"
  | "service.inventory-management-system"
  | "service.saas-platform-development"
  | "service.ui-ux-product-design"
  | "service.ai-automation-development"
  | "service.cloud-infrastructure-devops"
  | "service.desc.custom-website-development"
  | "service.desc.company-profile-website"
  | "service.desc.landing-page-development"
  | "service.desc.e-commerce-development"
  | "service.desc.custom-web-application"
  | "service.desc.admin-analytics-dashboards"
  | "service.desc.mobile-app-development"
  | "service.desc.erp-system-development"
  | "service.desc.crm-system-development"
  | "service.desc.hris-payroll-system"
  | "service.desc.inventory-management-system"
  | "service.desc.saas-platform-development"
  | "service.desc.ui-ux-product-design"
  | "service.desc.ai-automation-development"
  | "service.desc.cloud-infrastructure-devops"
  | "service.choose.title"
  | "service.choose.desc"
  | "service.estim.title"
  | "general.viewPortfolio"
  | "general.allServices";

export const translations = {
  en: {
    nav: {
      home: "Home",
      about: "About Us",
      services: "Services",
      whyUs: "Why Us",
      portfolio: "Portfolio",
      contact: "Contact",
      startProject: "Start Project",
      available: "Available for new projects",
    },
    hero: {
      badge: "Trusted Technology Partner",
      titlePre: "Transforming Ideas Into",
      titleAcc: "Digital Solutions",
      desc: "ZELLIO is a professional technology partner delivering custom websites, high-performance dashboards, mobile apps, and robust IT solutions for your business.",
      explore: "Explore Services",
      contact: "Contact Us",
    },
    service: {
      whyChoose: "Why Choose Our",
      timeline: "Estimated Timeline",
      tier: "Service Tier",
      note: "Note: Final timeline and pricing are subject to project complexity and specific technical requirements.",
      viewAll: "View All Services",
      elevate: "Elevate your digital presence.",
      "custom-website-development": "Custom Website Development",
      "company-profile-website": "Company Profile Website",
      "landing-page-development": "Landing Page Development",
      "e-commerce-development": "E-Commerce Development",
      "custom-web-application": "Custom Web Application",
      "admin-analytics-dashboards": "Admin & Analytics Dashboards",
      "mobile-app-development": "Mobile App Development",
      "erp-system-development": "ERP System Development",
      "crm-system-development": "CRM System Development",
      "hris-payroll-system": "HRIS & Payroll System",
      "inventory-management-system": "Inventory Management System",
      "saas-platform-development": "SaaS Platform Development",
      "ui-ux-product-design": "UI/UX & Product Design",
      "ai-automation-development": "AI & Automation Development",
      "cloud-infrastructure-devops": "Cloud Infrastructure & DevOps",
      desc: {
        "custom-website-development": "We build stunning, ultra-fast websites that look great on any screen and help your business make a lasting impression online.",
        "company-profile-website": "A professional digital home for your company. We help you build instant trust and introduce your business values to the world.",
        "landing-page-development": "Beautiful, focused landing pages designed specifically to turn your ad campaign clicks into actual leads and customers.",
        "e-commerce-development": "Your own custom online store, fully equipped with automated shipping rates, secure payment gateways, and a clean checkout experience.",
        "custom-web-application": "Tailored web applications built to simplify your team's workflow, manage business data, or bring your next SaaS product to life.",
        "admin-analytics-dashboards": "Clean data dashboards that turn complex spreadsheets into visual, easy-to-read charts so you can monitor your business in real-time.",
        "mobile-app-development": "Responsive, native-feeling iOS and Android mobile apps designed with a focus on ease of use and smooth performance.",
        "erp-system-development": "A unified system to organize your finance, inventory, HR, and operations. We connect all your department workflows in one place.",
        "crm-system-development": "Keep track of customer leads, log sales progress, and automate email follow-ups to make selling a breeze for your team.",
        "hris-payroll-system": "Simplify HR work by automating employee clock-ins, leave approvals, payroll calculations, and digital payslip delivery.",
        "inventory-management-system": "Say goodbye to pen and paper. Track stock levels, warehouse movements, and low-stock alerts automatically and accurately.",
        "saas-platform-development": "We take care of the complex stuff like multi-tenant setups, separate customer databases, and automated Stripe billing for your SaaS.",
        "ui-ux-product-design": "Interactive Figma wireframes, real user tests, and premium design systems to ensure your product is a joy for people to use.",
        "ai-automation-development": "We integrate smart AI tools and automated pipelines into your daily operations to handle repetitive tasks for your team.",
        "cloud-infrastructure-devops": "Secure, reliable cloud setups on AWS or GCP. We ensure your application is scalable, safe, and lightning fast.",
      },
      choose: {
        title: "Why Choose Our Services?",
        desc: "As a trusted tech partner, ZELLIO ensures that every line of code written for your project meets global standards for speed, security, and scalability.",
      },
      estim: {
        title: "Project Estimation",
      }
    },
    general: {
      viewPortfolio: "View Our Work",
      allServices: "View All Services"
    }
  },
  id: {
    nav: {
      home: "Beranda",
      about: "Tentang Kami",
      services: "Layanan",
      whyUs: "Kenapa Kami",
      portfolio: "Portofolio",
      contact: "Kontak",
      startProject: "Mulai Proyek",
      available: "Siap berkolaborasi untuk proyek baru",
    },
    hero: {
      badge: "Mitra Teknologi Terpercaya",
      titlePre: "Ubah Ide Menjadi",
      titleAcc: "Solusi Digital",
      desc: "ZELLIO adalah mitra teknologi terpercaya yang siap membantu Anda merancang dan membangun website kustom, dashboard canggih, aplikasi mobile, hingga infrastruktur server andal.",
      explore: "Jelajahi Layanan",
      contact: "Hubungi Kami",
    },
    service: {
      whyChoose: "Kenapa Pilih Layanan",
      timeline: "Estimasi Waktu",
      tier: "Kelas Layanan",
      note: "Catatan: Durasi pengerjaan dan biaya akhir disesuaikan dengan tingkat kesulitan serta kebutuhan spesifik proyek Anda.",
      viewAll: "Lihat Semua Layanan",
      elevate: "Tingkatkan reputasi digital bisnis Anda.",
      "custom-website-development": "Pengembangan Web Kustom",
      "company-profile-website": "Website Profil Perusahaan",
      "landing-page-development": "Pengembangan Landing Page",
      "e-commerce-development": "Pengembangan E-Commerce",
      "custom-web-application": "Aplikasi Web Kustom",
      "admin-analytics-dashboards": "Dashboard Admin & Analitik",
      "mobile-app-development": "Pembuatan Aplikasi Mobile",
      "erp-system-development": "Pengembangan Sistem ERP",
      "crm-system-development": "Pengembangan Sistem CRM",
      "hris-payroll-system": "Sistem HRIS & Payroll",
      "inventory-management-system": "Sistem Manajemen Inventaris",
      "saas-platform-development": "Pengembangan Platform SaaS",
      "ui-ux-product-design": "Desain UI/UX & Produk",
      "ai-automation-development": "Pengembangan AI & Otomatisasi",
      "cloud-infrastructure-devops": "Infrastruktur Cloud & DevOps",
      desc: {
        "custom-website-development": "Kami membuat website khusus yang elegan, cepat diakses, dan ramah Google untuk menaikkan citra profesional bisnis Anda.",
        "company-profile-website": "Website resmi perusahaan untuk membangun kepercayaan klien B2B, mengenalkan visi bisnis, dan memajang layanan Anda dengan rapi.",
        "landing-page-development": "Halaman penawaran khusus yang fokus dan cepat untuk mengubah klik iklan Google atau Meta Ads Anda menjadi pembeli potensial.",
        "e-commerce-development": "Toko online kustom yang dilengkapi dengan keranjang belanja, gerbang pembayaran aman, dan kalkulator ongkir otomatis.",
        "custom-web-application": "Sistem aplikasi web kustom untuk merapikan alur kerja internal kantor atau meluncurkan ide platform startup digital Anda.",
        "admin-analytics-dashboards": "Dashboard visualisasi data untuk mengubah laporan rumit menjadi grafik interaktif yang mudah dipantau secara real-time.",
        "mobile-app-development": "Pembuatan aplikasi Android & iOS berkualitas tinggi menggunakan Flutter atau React Native agar nyaman digunakan oleh pelanggan.",
        "erp-system-development": "Sistem terpadu untuk menyelaraskan laporan keuangan, logistik gudang, divisi HR, dan operasional bisnis dalam satu platform.",
        "crm-system-development": "Permudah tim sales melacak prospek calon pelanggan, mencatat data kontak, dan mengirim email follow-up otomatis.",
        "hris-payroll-system": "Sistem manajemen karyawan untuk mengotomatiskan absensi harian, pengajuan izin cuti, hingga pembuatan slip gaji bulanan.",
        "inventory-management-system": "Aplikasi pencatatan stok barang digital untuk memantau keluar masuk produk dan peringatan jika stok menipis secara akurat.",
        "saas-platform-development": "Pengembangan produk SaaS multi-tenant dengan pengelolaan database terpisah dan integrasi tagihan otomatis Stripe.",
        "ui-ux-product-design": "Pembuatan prototipe interaktif di Figma, riset pengguna, dan perancangan tata letak agar produk Anda terasa premium dan mudah dipakai.",
        "ai-automation-development": "Integrasi teknologi kecerdasan buatan dan bot asisten otomatis untuk menangani pekerjaan administratif harian tim Anda.",
        "cloud-infrastructure-devops": "Setup server cloud AWS/GCP yang aman, kontainerisasi Docker, serta sistem pemantauan berkala agar web Anda selalu lancar.",
      },
      choose: {
        title: "Kenapa Pilih Layanan Kami?",
        desc: "Sebagai mitra IT terpercaya, ZELLIO memastikan setiap baris kode yang ditulis selalu memenuhi standar global dalam hal kecepatan, keamanan, dan skalabilitas.",
      },
      estim: {
        title: "Estimasi Proyek",
      }
    },
    general: {
      viewPortfolio: "Lihat Portofolio",
      allServices: "Lihat Semua Layanan"
    }
  },
};
