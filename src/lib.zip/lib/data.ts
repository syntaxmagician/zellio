// ============================================================
// ZELLIO – IT Services & Digital Agency Site Data
// ============================================================

export const navLinks = [
  { label: "Home", href: "/" },
  { label: "About Us", href: "/#about" },
  { label: "Services", href: "/#services" },
  { label: "Why Us", href: "/#why-choose" },
  { label: "Portfolio", href: "/portfolio" },
  { label: "Contact", href: "/contact" },
];

export const trustedCompanies = [
  { name: "Tokopedia", abbrev: "TP" },
  { name: "Gojek", abbrev: "GJ" },
  { name: "Traveloka", abbrev: "TV" },
  { name: "Bank BRI", abbrev: "BRI" },
  { name: "Bank BCA", abbrev: "BCA" },
  { name: "Pertamina", abbrev: "PTM" },
  { name: "Telkomsel", abbrev: "TKM" },
  { name: "Astra", abbrev: "AST" },
];

export const stats = [
  { value: 150, suffix: "+", label: "Projects Delivered" },
  { value: 98, suffix: "%", label: "Client Satisfaction" },
  { value: 50, suffix: "+", label: "Enterprise Clients" },
  { value: 8, suffix: "+", label: "Years Experience" },
];

export const missionItems = [
  {
    icon: "Target",
    title: "Client-Centric Solutions",
    description:
      "We design and build every system tailored specifically to your business flow and strategic requirements.",
  },
  {
    icon: "Globe",
    title: "Global Coding Standards",
    description:
      "Our team adheres to strict international coding standards, ensuring highly clean, maintainable, and scalable codebases.",
  },
  {
    icon: "Award",
    title: "High-Performance Systems",
    description:
      "We don't settle for slow. We build custom websites, dashboards, and enterprise platforms optimized for speed and high traffic.",
  },
  {
    icon: "Users",
    title: "Expert Tech Engineers",
    description:
      "Our squad consists of top-tier full-stack developers, UI/UX designers, and cloud architects working dedicatedly for your project.",
  },
  {
    icon: "TrendingUp",
    title: "Continuous Tech Innovation",
    description:
      "We constantly adopt the latest tech stacks and security patches to keep your digital infrastructure ahead of competitors.",
  },
];

export const servicesData = [
  {
    id: 1,
    category: "Website",
    icon: "Monitor",
    title: "Custom Website Development",
    description: "Kami merancang website profesional yang elegan dan super cepat untuk membantu bisnis Anda tampil memukau di dunia digital.",
    duration: "4-6 Weeks",
    level: "Premium",
    color: "#FF3A2D",
    bgColor: "#FFEBEA",
    heroMedia: { type: "image" as const, url: "/hero/service_custom_web.jpg" }
  },
  {
    id: 2,
    category: "Website",
    icon: "Globe",
    title: "Company Profile Website",
    description: "Kesan pertama itu penting. Kami bantu merangkum identitas perusahaan Anda menjadi sebuah website yang profesional dan tepercaya.",
    duration: "3-5 Weeks",
    level: "Premium",
    color: "#FF3A2D",
    bgColor: "#FFEBEA",
    heroMedia: { type: "image" as const, url: "/hero/service_company_profile.jpg" }
  },
  {
    id: 3,
    category: "Website",
    icon: "FileText",
    title: "Landing Page Development",
    description: "Halaman web khusus yang berfokus untuk mengubah pengunjung dari kampanye iklan Anda menjadi pelanggan potensial.",
    duration: "1-2 Weeks",
    level: "Premium",
    color: "#f59e0b",
    bgColor: "#fef3c7",
    heroMedia: { type: "image" as const, url: "/hero/service_landing_page.jpg" }
  },
  {
    id: 4,
    category: "Website",
    icon: "ShoppingBag",
    title: "E-Commerce Development",
    description: "Toko online milik Anda sendiri, lengkap dengan fitur pembayaran otomatis, penghitungan ongkos kirim, dan manajemen stok yang rapi.",
    duration: "6-10 Weeks",
    level: "Enterprise",
    color: "#ec4899",
    bgColor: "#fce7f3",
    heroMedia: { type: "image" as const, url: "/hero/service_ecommerce.jpg" }
  },
  {
    id: 5,
    category: "Web App",
    icon: "Layers",
    title: "Custom Web Application",
    description: "Aplikasi web khusus yang dirancang untuk mempermudah alur kerja internal Anda atau mewujudkan ide produk digital Anda.",
    duration: "8-12 Weeks",
    level: "Enterprise",
    color: "#8b5cf6",
    bgColor: "#ede9fe",
    heroMedia: { type: "image" as const, url: "/hero/service_custom_web_app.jpg" }
  },
  {
    id: 6,
    category: "Dashboard",
    icon: "BarChart2",
    title: "Admin & Analytics Dashboards",
    description: "Ubah data rumit menjadi grafik yang mudah dipahami. Pantau kinerja bisnis secara real-time melalui dashboard visual yang interaktif.",
    duration: "6-10 Weeks",
    level: "Enterprise",
    color: "#e11d48",
    bgColor: "#ffe4e6",
    heroMedia: { type: "image" as const, url: "/hero/service_admin_dash.jpg" }
  },
  {
    id: 7,
    category: "Mobile",
    icon: "Smartphone",
    title: "Mobile App Development",
    description: "Aplikasi mobile responsif untuk iOS dan Android yang tidak hanya terlihat bagus, tapi juga sangat nyaman saat digunakan.",
    duration: "8-12 Weeks",
    level: "Premium",
    color: "#10b981",
    bgColor: "#d1fae5",
    heroMedia: { type: "image" as const, url: "/hero/service_mobile_app.jpg" }
  },
  {
    id: 8,
    category: "Enterprise",
    icon: "Database",
    title: "ERP System Development",
    description: "Sistem pusat yang cerdas untuk menghubungkan keuangan, inventaris, dan operasional harian dalam satu platform terintegrasi.",
    duration: "12-24 Weeks",
    level: "Enterprise",
    color: "#dc2626",
    bgColor: "#fee2e2",
    heroMedia: { type: "image" as const, url: "/hero/service_erp.jpg" }
  },
  {
    id: 9,
    category: "Enterprise",
    icon: "Users",
    title: "CRM System Development",
    description: "Sistem manajemen agar tim sales Anda dapat melacak prospek dan berinteraksi dengan pelanggan secara lebih terorganisir.",
    duration: "8-16 Weeks",
    level: "Enterprise",
    color: "#4f46e5",
    bgColor: "#e0e7ff",
    heroMedia: { type: "image" as const, url: "/hero/service_crm.jpg" }
  },
  {
    id: 10,
    category: "Enterprise",
    icon: "UserCheck",
    title: "HRIS & Payroll System",
    description: "Sistem HR modern untuk menyederhanakan manajemen absensi, pengaturan cuti, hingga pendistribusian slip gaji bulanan.",
    duration: "10-18 Weeks",
    level: "Enterprise",
    color: "#06b6d4",
    bgColor: "#cffafe",
    heroMedia: { type: "image" as const, url: "/hero/service_hris.jpg" }
  },
  {
    id: 11,
    category: "Enterprise",
    icon: "Package",
    title: "Inventory Management System",
    description: "Pantau pergerakan stok barang Anda secara akurat tanpa harus pusing dengan pencatatan manual di gudang.",
    duration: "6-12 Weeks",
    level: "Enterprise",
    color: "#84cc16",
    bgColor: "#ecfccb",
    heroMedia: { type: "image" as const, url: "/hero/service_inventory.jpg" }
  },
  {
    id: 12,
    category: "SaaS",
    icon: "Cpu",
    title: "SaaS Platform Development",
    description: "Pengembangan platform SaaS menyeluruh, mencakup sistem pembayaran berlangganan yang aman dan arsitektur pengguna yang andal.",
    duration: "12-20 Weeks",
    level: "Enterprise",
    color: "#a855f7",
    bgColor: "#f3e8ff",
    heroMedia: { type: "image" as const, url: "/hero/service_saas.jpg" }
  },
  {
    id: 13,
    category: "Design",
    icon: "Palette",
    title: "UI/UX & Product Design",
    description: "Desain antarmuka yang indah dan pengalaman pengguna yang intuitif untuk memastikan produk digital Anda menyenangkan saat dipakai.",
    duration: "3-6 Weeks",
    level: "Premium",
    color: "#6366f1",
    bgColor: "#e0e7ff",
    heroMedia: { type: "image" as const, url: "/hero/service_uiux.jpg" }
  },
  {
    id: 14,
    category: "AI",
    icon: "Brain",
    title: "AI & Automation Development",
    description: "Kami membantu mengintegrasikan teknologi AI agar tim Anda bisa menghemat waktu dari pekerjaan manual yang berulang.",
    duration: "8-16 Weeks",
    level: "Enterprise",
    color: "#14b8a6",
    bgColor: "#ccfbf1",
    heroMedia: { type: "image" as const, url: "/hero/service_ai.jpg" }
  },
  {
    id: 15,
    category: "Cloud",
    icon: "Cloud",
    title: "Cloud Infrastructure & DevOps",
    description: "Dukungan server cloud yang kokoh. Kami memastikan aplikasi Anda selalu menyala, aman, dan dapat diakses dengan cepat setiap saat.",
    duration: "3-6 Weeks",
    level: "Enterprise",
    color: "#0284c7",
    bgColor: "#e0f2fe",
    heroMedia: { type: "image" as const, url: "/hero/service_cloud.jpg" }
  }
];

// Fallback export to prevent broken imports during refactoring
export const trainingPrograms = servicesData;

export const whyChooseItems = [
  {
    icon: "Code2",
    title: "Elite Developers",
    description:
      "Our developers write clean, maintainable, and well-documented code using modern React, Node, and TypeScript ecosystems.",
    color: "#FF3A2D",
    bgColor: "#FFEBEA",
  },
  {
    icon: "Cpu",
    title: "Cutting-Edge Tech Stack",
    description:
      "We build on fast, lightweight frameworks like Next.js, TailwindCSS, Node.js, and Postgres to ensure peak performance.",
    color: "#06B6D4",
    bgColor: "#CFFAFE",
  },
  {
    icon: "ShieldAlert",
    title: "Robust Security Standards",
    description:
      "We implement data encryption, secure auth (OAuth/JWT), sanitization, and run security tests before final deployment.",
    color: "#22C55E",
    bgColor: "#DCFCE7",
  },
  {
    icon: "CalendarCheck",
    title: "Agile & On-Time Delivery",
    description:
      "We deliver in milestones using Scrum methodologies, giving you full visibility and ensuring we launch on schedule.",
    color: "#8B5CF6",
    bgColor: "#EDE9FE",
  },
];

export const developmentProcess = [
  {
    step: 1,
    title: "Consultation & Discovery",
    description: "Understand your business requirements, user persona, and technical scope.",
    icon: "MessageSquare",
  },
  {
    step: 2,
    title: "UI/UX Design",
    description: "Create interactive Figma prototypes and custom wireframes for your approval.",
    icon: "Palette",
  },
  {
    step: 3,
    title: "Development",
    description: "Agile sprints of clean coding, frontend building, and robust backend integrations.",
    icon: "Code2",
  },
  {
    step: 4,
    title: "QA & Testing",
    description: "Rigorous performance, security, responsive, and cross-browser testing.",
    icon: "ClipboardCheck",
  },
  {
    step: 5,
    title: "Deployment & Support",
    description: "Cloud deployment, SEO optimization, and 3 months of free maintenance support.",
    icon: "Award",
  },
];

// Fallback export
export const learningSteps = developmentProcess;

export const testimonials = [
  {
    id: 1,
    name: "Rizky Pratama",
    position: "CTO",
    company: "FinTech Solutions",
    avatar: "RP",
    rating: 5,
    review:
      "ZELLIO built our core payment dashboard. The level of professionalism, clean code, and speed of delivery exceeded our expectations. The real-time tracking graphs load instantly.",
    color: "#FF3A2D",
  },
  {
    id: 2,
    name: "Sari Dewi Kusuma",
    position: "Product Director",
    company: "RetailFlow Indonesia",
    avatar: "SD",
    rating: 5,
    review:
      "We hired them to build our multi-vendor e-commerce platform and admin portal. The system is extremely fast, responsive on mobile, and scales beautifully during high-traffic flash sales.",
    color: "#8B5CF6",
  },
  {
    id: 3,
    name: "Budi Santoso",
    position: "CEO",
    company: "LogiChain Logistics",
    avatar: "BS",
    rating: 5,
    review:
      "Their custom ERP system streamlined our logistics operations. The admin dashboard displays real-time tracking data across 5 provinces flawlessly. Our operational efficiency increased by 30%.",
    color: "#059669",
  },
  {
    id: 4,
    name: "Anisa Rahman",
    position: "Co-Founder",
    company: "EduSpace Platform",
    avatar: "AR",
    rating: 5,
    review:
      "They designed and built our SaaS web platform from scratch. The UI/UX is outstanding, and the backend is highly scalable. A truly elite tech partner that delivers what they promise.",
    color: "#D97706",
  },
];
